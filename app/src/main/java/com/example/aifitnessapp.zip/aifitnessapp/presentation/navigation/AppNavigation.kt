package com.example.aifitnessapp.presentation.navigation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.aifitnessapp.presentation.screens.*
import com.example.aifitnessapp.data.local.ActiveProfileManager
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@Composable
fun AppNavigation(navController: NavHostController, paddingValues: PaddingValues = PaddingValues()) {

    val activeProfileManager = remember { ActiveProfileManager(navController.context) }
    var activeProfileId by remember { mutableStateOf<Int?>(null) }

    // Observe active profile
    LaunchedEffect(Unit) {
        activeProfileManager.activeProfileId.collectLatest { id ->
            activeProfileId = id
        }
    }

    // Choose start screen
    val startDestination =
        if (activeProfileId == null) NavRoutes.ProfileSelection.route
        else NavRoutes.Home.route

    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = Modifier.padding(paddingValues)
    ) {

        // -----------------------------
        // PROFILE SELECTION SCREEN
        // -----------------------------
        composable(NavRoutes.ProfileSelection.route) {
            val scope = rememberCoroutineScope()

            ProfileSelectionScreen(
                onAddNewUser = { navController.navigate(NavRoutes.UserDetails.route) },
                onSelectProfile = { profile ->

                    // Save active profile
                    scope.launch {
                        activeProfileManager.setActiveProfile(profile.id)
                    }

                    // Navigate to home
                    navController.navigate(NavRoutes.Home.route) {
                        popUpTo(0)
                    }
                }
            )
        }

        // -----------------------------
        // USER DETAILS SCREEN
        // -----------------------------
        composable(NavRoutes.UserDetails.route) {
            UserDetailsScreen(
                onContinue = {
                    navController.navigate(NavRoutes.Home.route) {
                        popUpTo(0)
                    }
                }
            )
        }

        // -----------------------------
        // HOME SCREEN (FIXED)
        // -----------------------------
        composable(NavRoutes.Home.route) {
            HomeScreen(navController)
        }

        // -----------------------------
        // DIET
        // -----------------------------
        composable(NavRoutes.Diet.route) {
            DietScreen()
        }

        // -----------------------------
        // WORKOUT
        // -----------------------------
        composable(NavRoutes.Workout.route) {
            WorkoutScreen()
        }

        // -----------------------------
        // AI COACH
        // -----------------------------
        composable(NavRoutes.AiCoach.route) {
            AiCoachScreen()
        }

        // -----------------------------
        // DASHBOARD
        // -----------------------------
        composable(NavRoutes.Dashboard.route) {
            val pid = activeProfileId ?: 1
            DashboardScreen(profileId = pid)
        }

    }
}
