package com.example.aifitnessapp.domain.model

import org.json.JSONObject

data class MealBlock(
    val time: String,
    val items: List<String>,
    val calories: Int
)

data class SummaryBlock(
    val total_calories: Int,
    val nutrients: String,
    val tips: String
)

data class DietPlanJson(
    val breakfast: MealBlock,
    val mid_morning_snack: MealBlock,
    val lunch: MealBlock,
    val evening_snack: MealBlock,
    val dinner: MealBlock,
    val summary: SummaryBlock
) {
    companion object {
        fun fromJson(json: JSONObject): DietPlanJson {

            fun meal(block: JSONObject): MealBlock =
                MealBlock(
                    time = block.getString("time"),
                    items = block.getJSONArray("items").let { arr ->
                        List(arr.length()) { arr.getString(it) }
                    },
                    calories = block.getInt("calories")
                )

            val breakfast = meal(json.getJSONObject("breakfast"))
            val mid = meal(json.getJSONObject("mid_morning_snack"))
            val lunch = meal(json.getJSONObject("lunch"))
            val eve = meal(json.getJSONObject("evening_snack"))
            val dinner = meal(json.getJSONObject("dinner"))

            val summaryObj = json.getJSONObject("summary")
            val summary = SummaryBlock(
                total_calories = summaryObj.getInt("total_calories"),
                nutrients = summaryObj.getString("nutrients"),
                tips = summaryObj.getString("tips")
            )

            return DietPlanJson(breakfast, mid, lunch, eve, dinner, summary)
        }
    }
}
