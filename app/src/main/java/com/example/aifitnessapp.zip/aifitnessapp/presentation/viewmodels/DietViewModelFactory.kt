package com.example.aifitnessapp.presentation.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.aifitnessapp.data.local.dao.SavedDietDao

class DietViewModelFactory(
    private val apiKey: String,
    private val savedDao: SavedDietDao,
    private val profileId: Int
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DietPlanViewModel::class.java)) {
            return DietPlanViewModel(apiKey, savedDao, profileId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
