package com.example.aifitnessapp.presentation.viewmodels

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aifitnessapp.data.local.dao.SavedDietDao
import com.example.aifitnessapp.domain.model.DietPlanJson
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class DietPlanViewModel(
    private val apiKey: String,
    private val savedDao: SavedDietDao,
    private val profileId: Int
) : ViewModel() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val _dietJson = MutableStateFlow<DietPlanJson?>(null)
    val dietJson: StateFlow<DietPlanJson?> = _dietJson

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val gson = Gson()

    fun generateDiet(
        name: String,
        age: Int,
        weight: Float,
        target: Float,
        height: Float
    ) {
        viewModelScope.launch {
            _isLoading.value = true

            val prompt = """
Return ONLY a valid JSON with this exact structure:

{
  "breakfast": {"time":"","items":[],"calories":0},
  "mid_morning_snack": {"time":"","items":[],"calories":0},
  "lunch": {"time":"","items":[],"calories":0},
  "evening_snack": {"time":"","items":[],"calories":0},
  "dinner": {"time":"","items":[],"calories":0},
  "summary": {"total_calories":0, "nutrients":"", "tips":""}
}

RULES:
- Indian vegetarian foods only.
- 2–4 items per meal.
- Calories must be realistic.

USER:
Name: $name
Age: $age
Weight: $weight
Target: $target
Height: $height
""".trimIndent()

            try {
                val bodyJson = JSONObject().apply {
                    put("contents", JSONArray().put(
                        JSONObject().put("parts",
                            JSONArray().put(JSONObject().put("text", prompt))
                        )
                    ))
                }

                val request = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key=$apiKey")
                    .addHeader("Content-Type", "application/json")
                    .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = withContext(Dispatchers.IO) { client.newCall(request).execute() }
                val responseBody = response.body?.string() ?: ""

                Log.d("DietVM", "RAW: $responseBody")

                val json = JSONObject(responseBody)

                if (!json.has("candidates")) {
                    throw Exception("Invalid response: no candidates")
                }

                val text = json
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                // Parse JSON from AI
                val parsed = gson.fromJson(text, DietPlanJson::class.java)

                _dietJson.value = parsed

                // Save offline
                viewModelScope.launch {
                    savedDao.savePlan(
                        com.example.aifitnessapp.domain.model.SavedDietPlan(
                            profileId = profileId,
                            timestamp = System.currentTimeMillis(),
                            json = text
                        )
                    )
                }

            } catch (e: Exception) {
                Log.e("DietVM", "Error: ${e.message}", e)
            }

            _isLoading.value = false
        }
    }
}
