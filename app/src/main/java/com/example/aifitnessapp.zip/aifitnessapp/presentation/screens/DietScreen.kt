package com.example.aifitnessapp.presentation.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.aifitnessapp.BuildConfig
import com.example.aifitnessapp.data.local.DatabaseModule
import com.example.aifitnessapp.data.local.ActiveProfileManager
import com.example.aifitnessapp.ui.theme.PremiumLightBackground
import com.example.aifitnessapp.ui.theme.GlassCard
import com.example.aifitnessapp.ui.theme.PremiumTitle
import com.example.aifitnessapp.presentation.viewmodels.DietPlanViewModel
import com.example.aifitnessapp.presentation.viewmodels.DietViewModelFactory
import kotlinx.coroutines.flow.collectLatest

@Composable
fun DietScreen() {

    PremiumLightBackground {

        val context = LocalContext.current
        val apiKey = BuildConfig.OPENAI_API_KEY

        val activeProfileManager = remember { ActiveProfileManager(context) }
        var activeProfileId by remember { mutableStateOf<Int?>(null) }

        // Load active profile
        LaunchedEffect(Unit) {
            activeProfileManager.activeProfileId.collectLatest { id ->
                activeProfileId = id
            }
        }

        if (activeProfileId == null) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                CircularProgressIndicator()
            }
            return@PremiumLightBackground
        }

        // Load profile from Room
        val db = DatabaseModule.getDatabase(context)
        val profileFlow = remember { db.profileDao().observeProfile(activeProfileId!!) }
        val profile by profileFlow.collectAsState(initial = null)

        if (profile == null) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("Loading profile...")
            }
            return@PremiumLightBackground
        }

        // ViewModel
        val savedDao = db.savedDietDao()
        val vm: DietPlanViewModel = viewModel(
            factory = DietViewModelFactory(apiKey, savedDao, profile!!.id)
        )

        val diet by vm.dietJson.collectAsState()
        val loading by vm.isLoading.collectAsState()

        Scaffold(
            floatingActionButton = {
                FloatingActionButton(
                    onClick = {
                        vm.generateDiet(
                            name = profile!!.name,
                            age = profile!!.age,
                            weight = profile!!.weight,
                            target = profile!!.targetWeight,
                            height = profile!!.heightCm
                        )
                    }
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Generate Diet")
                }
            },
            containerColor = androidx.compose.ui.graphics.Color.Transparent
        ) { pad ->

            Column(
                modifier = Modifier
                    .padding(pad)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {

                PremiumTitle("AI Diet Plan")

                Spacer(Modifier.height(20.dp))

                if (loading) {
                    Box(Modifier.fillMaxWidth(), Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }

                if (diet == null) {
                    Text("Tap refresh to generate your personalized AI diet plan.")
                } else {
                    GlassCard {
                        Text("Breakfast: ${diet!!.breakfast.items.joinToString()}")
                        Spacer(Modifier.height(8.dp))
                        Text("Lunch: ${diet!!.lunch.items.joinToString()}")
                        Spacer(Modifier.height(8.dp))
                        Text("Dinner: ${diet!!.dinner.items.joinToString()}")
                    }
                }
            }
        }
    }
}
