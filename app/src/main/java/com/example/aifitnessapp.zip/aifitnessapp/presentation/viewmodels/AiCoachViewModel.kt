package com.example.aifitnessapp.presentation.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aifitnessapp.data.local.DatabaseModule
import com.example.aifitnessapp.domain.model.ChatMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class AiCoachViewModel(
    private val apiKey: String,
    private val context: Context
) : ViewModel() {

    private val client = OkHttpClient()
    private val chatDao = DatabaseModule.getDatabase(context).chatDao()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _isStreaming = MutableStateFlow(false)
    val isStreaming: StateFlow<Boolean> = _isStreaming

    init {
        loadChat()
    }

    private fun loadChat() {
        viewModelScope.launch {
            chatDao.getAll().collect { list ->
                _messages.value = list
            }
        }
    }

    fun sendMessage(userText: String) {
        addMessage("user", userText)
        callGemini(userText)
    }

    private fun addMessage(role: String, text: String) {
        viewModelScope.launch {
            chatDao.insert(ChatMessage(role = role, content = text))
        }
    }

    private fun callGemini(prompt: String) {
        viewModelScope.launch {

            _isStreaming.value = true

            val json = JSONObject().apply {
                put(
                    "contents",
                    JSONArray().apply {
                        put(
                            JSONObject()
                                .put(
                                    "parts",
                                    JSONArray().put(
                                        JSONObject().put(
                                            "text",
                                            "You are a friendly AI Fitness Coach. Respond conversationally.\n\nUser: $prompt"
                                        )
                                    )
                                )
                        )
                    }
                )
            }

            val body = json
                .toString()
                .toRequestBody("application/json".toMediaType())

            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            try {
                val res = client.newCall(req).execute()
                val resStr = res.body?.string() ?: ""

                val obj = JSONObject(resStr)
                val text = obj
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                addMessage("assistant", text)

            } catch (e: Exception) {
                addMessage("assistant", "⚠ Error: ${e.message}")
            }

            _isStreaming.value = false
        }
    }
}
